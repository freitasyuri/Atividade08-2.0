﻿using CursoLP2.Atividade08;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CursoLP2
{
    internal class Program
    {
        static void Main(string[] args)
        {
            string separador = "---------------------------------", jnome;
            int op = 0, jestoque, i = 1;
            double jpreco;
            
            do
            {
                Console.WriteLine("PLAYSTATION");
                Console.WriteLine(separador);
                Console.WriteLine("1 - Jogos.");
                Console.WriteLine("2 - Cliente.");
                Console.WriteLine("3 - Compras.");
                Console.WriteLine("4 - Sair");
                Console.WriteLine("Escolha uma opção:");
                op = int.Parse(Console.ReadLine());
                Console.Clear();
               
                
                switch (op)
                {
                    
                    case 1:
                    {
                        Jogo jogo = new Jogo();

                        Console.WriteLine("PLAYSTATION");
                        Console.WriteLine(separador);
                           do
                           {
                               
                               Console.WriteLine($"Digite nome do {i++}º jogo: ");
                               jnome = Console.ReadLine();
                                

                           } while (!jogo.SetJnome(jnome));
                           
                           do
                           {
                              Console.WriteLine("Digite o preço do jogo:");
                              jpreco = double.Parse(Console.ReadLine());

                            } while (!jogo.SetJpreco(jpreco));

                        Console.WriteLine("Digite a classificação indicativa:");
                        jogo.SetJclassindicativa(int.Parse(Console.ReadLine()));
                           do
                           {
                              Console.WriteLine("Digite o estoque:");
                              jestoque = int.Parse(Console.ReadLine());

                           } while (!jogo.SetJestoque(jestoque));
                            Console.Clear();
                        
                           break;
                            
                    }
                        
                }
                op++;
            } while (op != 4);

            Console.ReadKey();
        }
    }
}
