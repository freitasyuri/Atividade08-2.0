﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CursoLP2.Atividade08
{
    internal class Cliente
    {
        private string Cnome;
        private int C_idade;
        private  double Csaldo;

        public Cliente(string cnome, int c_idade, double csaldo) 
        {
            Cnome = cnome;
            C_idade = c_idade;
            Csaldo = csaldo;
        }

        public void SetCnome(string cnome) 
        {
            
            if (Cnome== null)
            {
                Console.WriteLine("O nome do cliente não pode ser nulo!Tente novamente.");
            }
            else if (Cnome.Length < 2)
            {
                Console.WriteLine("O nome do cliente não pode ter menos que dois caracteres!Tente novamente.");
            }
            else 
            {
                Cnome = cnome;
            }
           

        }
        public string GetCnome() { return Cnome; }
        public void SetC_idade(int c_idade) 
        {  

            if(C_idade < 0)
            {
                Console.WriteLine("A idade não pode ser negativo!Tente novamnete.");
            }
            else
            {
                C_idade = c_idade;
            }
            
        }
        public int GetC_idade() { return C_idade; }
        public  void SetCsaldo(double csaldo)
        { 
            
            if (csaldo < 0)
            {
                Console.WriteLine("O saldo não pode ser negativo!Tente novamnete.");
            }
            else
            {
                Csaldo = csaldo;
            }
            
        }
        public double GetCsaldo() { return Csaldo; }

        public double AdicionarSaldo(double valor)
        { 
            return Csaldo + valor;
        }
        public void ComprarJogo(Jogo jogo)
        {
            if (jogo == null)
            {
                Console.WriteLine("Não possivel comprar esse jogo porque o preço dele é nulo!Tente novamente.");
            }
            else if (C_idade != jogo.GetJclassindicativa())
            {
                Console.WriteLine("Não possivel comprar esse jogo porque a idade do cliente não é compativel com a classificação indicativa dele!Tente novamente.");
            }
            else if(Csaldo > jogo.GetJpreco() || jogo.GetJestoque() < 0)
            {
                Console.WriteLine("Não possivel comprar esse jogo porque o saldo do cliente é menor que o preço do jogo ou porque o estoque do jogo é nulo!Tente noavemnte.");
            }
            else if (Csaldo > jogo.GetJpreco() && jogo.GetJestoque() < 0)
            {
                Console.WriteLine("Não possivel comprar esse jogo porque o saldo do cliente é menor que o preço do jogo!Tente novamente.");
            }
            else
            {
                Csaldo = Csaldo - jogo.GetJpreco();
            }
            
        }
    }
}
