﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CursoLP2.Atividade08
{
    internal class Jogo
    {
        private string Jnome;
        private double Jpreco;
        private int Jclassindicativa;
        private int Jestoque;

        public static List<Jogo> lista_de_jogos = new List<Jogo>();
        public Jogo(string jnome, double jpreco, int jclassindicativa, int jestoque)
        {
            Jnome = jnome;
            Jpreco = jpreco;
            Jclassindicativa = jclassindicativa;
            Jestoque = jestoque;
            lista_de_jogos.Add(this);
        }
        public Jogo()
        {

        }
        public bool SetJnome(string jnome) 
        {
            
            if (string.IsNullOrWhiteSpace(jnome))
            {
                Console.WriteLine("O nome do jogo não pode ser nulo!Tente novamente.");
                return false;
            }
            else if (jnome.Length < 2)
            {
                Console.WriteLine("O nome do jogo não pode ter menos que dois caracteres!Tente novamente.");
                return false;
            }
           
               Jnome = jnome;
               return true;
                
           
        }
        public string GetJnome() { return Jnome; }
        public bool SetJpreco(double jpreco) 
        { 
            if(jpreco < 0)
            {
                Console.WriteLine("O preço não pode ser negativo!Tente novamente.");
                return false;
            }
 
            Jpreco = jpreco;
            return true;

        }
        public double GetJpreco() { return Jpreco; }
        public void SetJclassindicativa (int jclassindicativa) { Jclassindicativa = jclassindicativa; }
        public int GetJclassindicativa () { return Jclassindicativa; }
        public bool SetJestoque (int jestoque) 
        {  
            
            if (jestoque < 0)
            {
                Console.WriteLine("O estoque não pode ser negativo!Tente novamnete.");
                return false;
            }
           
            Jestoque = jestoque;
            return true;
            
        }
       public int GetJestoque () { return Jestoque; }


        public double AplicarDesconto(double percentual)
        {
            percentual = Jpreco % percentual;

            return Jpreco - percentual;
        }
        public int Vender(int quantidade)
        {

            return Jestoque - quantidade;
        }
    }
}
